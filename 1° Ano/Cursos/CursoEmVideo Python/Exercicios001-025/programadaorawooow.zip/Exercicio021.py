import pygame
pygame.init()
pygame.mixer_music.load('fart.mp3')
pygame.mixer_music.play(-1)
input()
pygame.event.wait()